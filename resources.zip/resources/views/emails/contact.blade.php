<h2> {{ $data->nombre }}</h2>
<br>

<strong>Detalles: </strong><br>
<strong>Nombre: </strong>{{ $data->nombre }} <br>
<strong>Correo: </strong>{{ $data->correo }} <br>
<strong>Teléfono: </strong>{{ $data->telefono }} <br>
<strong>Asunto: </strong>{{ $data->asunto }} <br>
<strong>Mensaje: </strong>{{ $data->user_query }} <br><br>

Muchas gracias
