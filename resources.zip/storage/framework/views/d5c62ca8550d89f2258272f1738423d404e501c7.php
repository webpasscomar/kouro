 <?php $__env->slot('header', null, []); ?> 
    <h1 class="text-gray-900"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a> | Existencias en Stock</h1>
 <?php $__env->endSlot(); ?>

<div class="py-12">
    <div class="max-w-7xl mx-auto sm:px6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg px-4 py-4">


            <div class="grid grid-cols-1 sm:grid-cols-3">
                <div class="py-3">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['type' => 'text','placeholder' => 'Texto a buscar','wire:model' => 'search','class' => 'w-full']]); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'text','placeholder' => 'Texto a buscar','wire:model' => 'search','class' => 'w-full']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </div>
            </div>

            <?php if($modal): ?>
                <?php echo $__env->make('livewire.backend.historias-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            <table class="table-auto w-full">
                <thead>
                    <tr class="bg-gray-200 text-gray-700">
                        <th class="cursor-pointer px-4 py-2" wire:click="order('id')">ID
                            
                            <?php if($sort == 'id'): ?>
                                <?php if($order == 'asc'): ?>
                                    <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                <?php endif; ?>
                            <?php else: ?>
                                <i class="fas fa-sort float-right mt-1"></i>
                            <?php endif; ?>
                        </th>
                        <th class="cursor-pointer px-4 py-2" wire:click="order('nombre')">Nombre
                            
                            <?php if($sort == 'nombre'): ?>
                                <?php if($order == 'asc'): ?>
                                    <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                <?php endif; ?>
                            <?php else: ?>
                                <i class="fas fa-sort float-right mt-1"></i>
                            <?php endif; ?>

                        </th>
                        <th class="cursor-pointer px-4 py-2" wire:click="order('color')">Color
                            
                            <?php if($sort == 'color'): ?>
                                <?php if($order == 'asc'): ?>
                                    <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                <?php endif; ?>
                            <?php else: ?>
                                <i class="fas fa-sort float-right mt-1"></i>
                            <?php endif; ?>
                        </th>
                        <th class="cursor-pointer px-4 py-2" wire:click="order('talle')">talle
                            
                            <?php if($sort == 'talle'): ?>
                                <?php if($order == 'asc'): ?>
                                    <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                <?php endif; ?>
                            <?php else: ?>
                                <i class="fas fa-sort float-right mt-1"></i>
                            <?php endif; ?>
                        </th>
                        <th class="cursor-pointer px-4 py-2" wire:click="order('stock')">Stock
                            
                            <?php if($sort == 'stock'): ?>
                                <?php if($order == 'asc'): ?>
                                    <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                <?php endif; ?>
                            <?php else: ?>
                                <i class="fas fa-sort float-right mt-1"></i>
                            <?php endif; ?>
                        </th>

                        <th class="px-4 py-2">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $sku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="border px-4 py-2"><?php echo e($item->id); ?></td>
                            <td class="border px-4 py-2"><?php echo e($item->nombre); ?></td>
                            <td class="border px-4 py-2"><?php echo e($item->color); ?></td>
                            <td class="border px-4 py-2"><?php echo e($item->talle); ?></td>
                            <td class="border px-4 py-2"><?php echo e($item->stock); ?></td>
                            <td class="border px-4 py-2 text-center">
                                <button wire:click="detalle(<?php echo e($item->id); ?>)"
                                    class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4">Detalle</button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <?php echo e($sku->links()); ?>


        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\lbase\resources\views/livewire/backend/historias.blade.php ENDPATH**/ ?>