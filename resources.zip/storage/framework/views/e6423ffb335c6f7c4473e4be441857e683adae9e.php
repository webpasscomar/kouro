 <?php $__env->slot('header', null, []); ?> 
    <h1 class="text-gray-900"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a> | Pedidos</h1>
 <?php $__env->endSlot(); ?>


<div class="py-12">
    <div class="max-w-7xl mx-auto sm:px6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg px-4 py-4">
            <?php if($modal==1): ?>
                <?php echo $__env->make('livewire.backend.pedidos-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <?php if($modal==0): ?>
            <div class="grid grid-cols-1 sm:grid-cols-3">
                <div>
                    <button wire:click="crear()"
                        class="bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 my-3">+ Nuevo Pedido</button>
                </div>
                <div class="py-3">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['type' => 'text','placeholder' => 'Texto a buscar','wire:model' => 'search','class' => 'w-full']]); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'text','placeholder' => 'Texto a buscar','wire:model' => 'search','class' => 'w-full']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </div>
            </div>
            <table class="table-auto w-full">
                        <thead>
                            <tr class="bg-gray-200 text-gray-700">
                                <th class="cursor-pointer px-4 py-2" wire:click="order('id')">ID
                                    
                                    <?php if($sort == 'id'): ?>
                                        <?php if($order == 'asc'): ?>
                                            <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                        <?php else: ?>
                                            <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <i class="fas fa-sort float-right mt-1"></i>
                                    <?php endif; ?>
                                </th>
                                <th class="cursor-pointer px-4 py-2" wire:click="order('fecha')">Fecha
                                    
                                    <?php if($sort == 'fecha'): ?>
                                        <?php if($order == 'asc'): ?>
                                            <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                        <?php else: ?>
                                            <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <i class="fas fa-sort float-right mt-1"></i>
                                    <?php endif; ?>

                                </th>
                                <th class="cursor-pointer px-4 py-2" wire:click="order('apellido')">Apellido
                                    
                                    <?php if($sort == 'apellido'): ?>
                                        <?php if($order == 'asc'): ?>
                                            <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                        <?php else: ?>
                                            <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <i class="fas fa-sort float-right mt-1"></i>
                                    <?php endif; ?>
                                </th>
                                <th class="cursor-pointer px-4 py-2" wire:click="order('nombre')">Nombre
                                    
                                    <?php if($sort == 'nombre'): ?>
                                        <?php if($order == 'asc'): ?>
                                            <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                        <?php else: ?>
                                            <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <i class="fas fa-sort float-right mt-1"></i>
                                    <?php endif; ?>
                                </th>
                                <!-- <th class="cursor-pointer px-4 py-2" wire:click="order('status_mp')">Status Pago
                                    
                                    <?php if($sort == 'status_mp'): ?>
                                        <?php if($order == 'asc'): ?>
                                            <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                        <?php else: ?>
                                            <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <i class="fas fa-sort float-right mt-1"></i>
                                    <?php endif; ?>
                                </th>
                                <th class="cursor-pointer px-4 py-2" wire:click="order('detail_mp')">Detalle Pago
                                    
                                    <?php if($sort == 'status_mp'): ?>
                                        <?php if($order == 'asc'): ?>
                                            <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                        <?php else: ?>
                                            <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <i class="fas fa-sort float-right mt-1"></i>
                                    <?php endif; ?>
                                </th>
                                <th class="cursor-pointer px-4 py-2" wire:click="order('transac_mp')">ID Pago
                                    
                                    <?php if($sort == 'transac_mp'): ?>
                                        <?php if($order == 'asc'): ?>
                                            <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                        <?php else: ?>
                                            <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <i class="fas fa-sort float-right mt-1"></i>
                                    <?php endif; ?>
                                </th> -->
                                <th class="cursor-pointer px-4 py-2" wire:click="order('estado')">Estado
                                    
                                    <?php if($sort == 'estado'): ?>
                                        <?php if($order == 'asc'): ?>
                                            <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                        <?php else: ?>
                                            <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <i class="fas fa-sort float-right mt-1"></i>
                                    <?php endif; ?>
                                </th>
                                <th class="px-4 py-2">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="border px-4 py-2"><?php echo e($pedido->id); ?></td>
                                    <td class="border px-4 py-2"><?php echo e($pedido->fecha); ?></td>
                                    <td class="border px-4 py-2"><?php echo e($pedido->apellido); ?></td>
                                    <td class="border px-4 py-2"><?php echo e($pedido->nombre); ?></td>
                                    <!-- <td class="border px-4 py-2"><?php echo e($pedido->status_mp); ?></td>
                                    <td class="border px-4 py-2"><?php echo e($pedido->detail_mp); ?></td>
                                    <td class="border px-4 py-2"><?php echo e($pedido->transac_mp); ?></td> -->
                                    <!-- <td class="border px-4 py-2"><?php echo e($pedido->estado); ?></td> -->
                                    <td class="border px-4 py-2"><?php echo e($pedido->estado->nombre); ?></td>
                                    <td class="border px-4 py-2 text-center">
                                        <button wire:click="detalle(<?php echo e($pedido->id); ?>)"
                                            class="bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4">Detalle</button>

                                            <!-- solo se puede editar en pendiente o en preparacion -->
                                        <?php if($pedido->estado_id == 1 || $pedido->estado_id == 2): ?>
                                            <button wire:click="editar(<?php echo e($pedido->id); ?>)"
                                                class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4">Editar</button>

                                                <button wire:click="$emit('alertDelete',<?php echo e($pedido->id); ?>)"
                                                   class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4">Borrar</button>

                                        <?php endif; ?>

                                        <button wire:click="verpago(<?php echo e($pedido->id); ?>)"
                                            class="bg-gray-200 hover:bg-gray-400 text-black font-bold py-2 px-4">Ver Pago</button>

                                        <button wire:click="cobrarmp(<?php echo e($pedido->id); ?>)"
                                                class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4">Cobrar con MP</button>


                                        </td>
                                </tr>
                                <?php for($i = 0; $i < $cantidad_detalle; $i++): ?>
                                        <?php if($muestra_detalle[$i]['id'] == $pedido->id): ?>
                                            <?php if($muestra_detalle[$i]['ver'] == 1): ?>
                                                <tr class="border">
                                                    <td colspan=6>
                                                        <table class="table-auto w-full">
                                                            <th>Codigo</th>
                                                            <th>Cantidad</th>
                                                            <th>Precio</th>
                                                            <th>Sub-Total</th>
                                                            <th>Talle</th>
                                                            <th>Color</th>
                                                            <th>Producto</th>
                                                            <?php $__currentLoopData = $pedidos_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($items->pedido_id == $muestra_detalle[$i]['id']): ?>
                                                                    <tr>
                                                                        <td class="border" ><?php echo e($items->sku->producto_id); ?></td>
                                                                        <td class="border" ><?php echo e($items->cantidad); ?></td>
                                                                        <td class="border"><?php echo e($items->precioUnitario); ?></td>
                                                                        <td class="border" ><?php echo e($items->precioItem); ?></td>
                                                                        <td class="border"><?php echo e($items->sku->talle->talle); ?></td>
                                                                        <td class="border"><?php echo e($items->sku->color->color); ?></td>
                                                                        <td class="border"><?php echo e($items->sku->producto->nombre); ?></td>
                                                                    </tr>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </table>

                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                <?php endfor; ?>



                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
            </table>

                    <?php echo e($pedidos->links()); ?>

            <?php endif; ?>
            <?php if($modalpago==1): ?>
                <?php echo $__env->make('livewire.backend.verpago-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\lbase\resources\views/livewire/backend/pedidos.blade.php ENDPATH**/ ?>