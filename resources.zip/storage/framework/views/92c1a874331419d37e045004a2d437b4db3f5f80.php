 <?php $__env->slot('header', null, []); ?> 
    <h1 class="text-gray-900"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a> | Gestión de Categorías</h1>
 <?php $__env->endSlot(); ?>

<div class="py-12">
    <div class="max-w-7xl mx-auto sm:px6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg px-4 py-4">

            <div class="grid grid-cols-1 sm:grid-cols-3">
                <div>
                    <button wire:click="crear()"
                        class="bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 my-3">+
                        Nueva categoría</button>
                </div>
                <div class="py-3">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['type' => 'text','placeholder' => 'Texto a buscar','wire:model' => 'search','class' => 'w-full']]); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'text','placeholder' => 'Texto a buscar','wire:model' => 'search','class' => 'w-full']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </div>
            </div>

            <?php if($modal): ?>
                <?php echo $__env->make('livewire.backend.categorias-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>


            <table class="table-auto w-full">
                <thead>
                    <tr class="bg-gray-200 text-gray-700">
                        <th class="cursor-pointer px-4 py-2" wire:click="order('id')">Id

                            <?php if($sort == 'id'): ?>
                                <?php if($order == 'asc'): ?>
                                    <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                <?php endif; ?>
                            <?php else: ?>
                                <i class="fas fa-sort float-right mt-1"></i>
                            <?php endif; ?>
                        </th>
                        <th class="cursor-pointer px-4 py-2">Imagen</th>
                        <th class="cursor-pointer px-4 py-2" wire:click="order('categoriaPadre_id')">Padre

                            <?php if($sort == 'categoriaPadre_id'): ?>
                                <?php if($order == 'asc'): ?>
                                    <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                <?php endif; ?>
                            <?php else: ?>
                                <i class="fas fa-sort float-right mt-1"></i>
                            <?php endif; ?>
                        </th>
                        <th class="cursor-pointer px-4 py-2" wire:click="order('categoria')">Nombre

                            <?php if($sort == 'categoria'): ?>
                                <?php if($order == 'asc'): ?>
                                    <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                <?php endif; ?>
                            <?php else: ?>
                                <i class="fas fa-sort float-right mt-1"></i>
                            <?php endif; ?>
                        </th>
                        <th class="cursor-pointer px-4 py-2" wire:click="order('slug')">Slug

                            <?php if($sort == 'categoria'): ?>
                                <?php if($order == 'asc'): ?>
                                    <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                <?php endif; ?>
                            <?php else: ?>
                                <i class="fas fa-sort float-right mt-1"></i>
                            <?php endif; ?>
                        </th>

                        <?php if($sort == 'descripcion'): ?>
                            <?php if($order == 'asc'): ?>
                                <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                            <?php else: ?>
                                <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                            <?php endif; ?>
                        <?php else: ?>
                            <i class="fas fa-sort float-right mt-1"></i>
                        <?php endif; ?>
                        </th>
                        <th class="cursor-pointer px-4 py-2" wire:click="order('orden')">Orden

                            <?php if($sort == 'orden'): ?>
                                <?php if($order == 'asc'): ?>
                                    <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                <?php endif; ?>
                            <?php else: ?>
                                <i class="fas fa-sort float-right mt-1"></i>
                            <?php endif; ?>
                        </th>
                        <th class="cursor-pointer px-4 py-2" wire:click="order('estado')">Estado

                            <?php if($sort == 'estado'): ?>
                                <?php if($order == 'asc'): ?>
                                    <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                <?php endif; ?>
                            <?php else: ?>
                                <i class="fas fa-sort float-right mt-1"></i>
                            <?php endif; ?>
                        </th>
                        <th class="px-4 py-2">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="border px-4 py-2"><?php echo e($categoria->id); ?></td>
                            <td class="border px-4 py-2">
                                <div class="flex-shrink-0 h-10 w-10">
                                    <img class="h-10 w-10 rounded-full"
                                        src="<?php echo e(asset('storage/categorias/' . $categoria->imagen)); ?>" alt="">
                                </div>
                            </td>
                            <td class="border px-4 py-2"><?php echo e($categoria->categoriaPadre_id); ?></td>
                            <td class="border px-4 py-2"><?php echo e($categoria->categoria); ?></td>
                            <td class="border px-4 py-2"><?php echo e($categoria->slug); ?></td>
                            <td class="border px-4 py-2"><?php echo e($categoria->orden); ?></td>
                            <td class="border px-4 py-2 text-center">
                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('toggle-button',
                                    [
                                        'model' => $categoria,
                                        'field' => 'estado',
                                    ])->html();
} elseif ($_instance->childHasBeenRendered($categoria->id)) {
    $componentId = $_instance->getRenderedChildComponentId($categoria->id);
    $componentTag = $_instance->getRenderedChildComponentTagName($categoria->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($categoria->id);
} else {
    $response = \Livewire\Livewire::mount('toggle-button',
                                    [
                                        'model' => $categoria,
                                        'field' => 'estado',
                                    ]);
    $html = $response->html();
    $_instance->logRenderedChild($categoria->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            </td>
                            <td class="border px-4 py-2 text-center">
                                <button wire:click="editar(<?php echo e($categoria->id); ?>)"
                                    class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4">Editar</button>
                                <button wire:click="$emit('alertDelete',<?php echo e($categoria->id); ?>)"
                                    class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4">Borrar</button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>


            <?php echo e($categorias->links()); ?>



        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\lbase\resources\views/livewire/backend/categorias.blade.php ENDPATH**/ ?>