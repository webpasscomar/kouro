<div>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.header','data' => []]); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        Shop
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px6 lg:px-8">

            
            <div class="flex flex-wrap">
                <div class="w-3/4 p-4">
                    <?php if($productos->count() > 0): ?>
                        <div class="grid grid-cols-3 gap-4">

                            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('producto', $producto->id)); ?>">
                                    <div class="bg-white rounded-lg overflow-hidden shadow-md">
                                        <img class="w-full h-56 object-cover object-center"
                                            src="<?php echo e(asset('storage/productos/' . $producto->id . '.jpg')); ?>"
                                            alt="<?php echo e($producto->titulo); ?>">
                                        <div class="p-4">
                                            <h2 class="text-gray-900 font-bold text-xl mb-2"><?php echo e($producto->nombre); ?>

                                            </h2>
                                            <p class="text-gray-700 text-base"><?php echo e($producto->descripcion); ?></p>
                                            <p class="text-gray-700 text-base font-bold mt-2"><?php echo e($producto->precio); ?>

                                            </p>
                                        </div>

                                    </div>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="mt-4">
                            <?php echo e($productos->links()); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="w-1/4 p-4">
                    <h2 class="text-gray-900 font-bold text-xl mb-2">Categorías</h2>
                    <ul class="text-gray-700 text-base">
                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="mb-2">
                                <a href="#"
                                    wire:click.prevent="setCategoria('<?php echo e($categoria->slug); ?>')"><?php echo e($categoria->categoria); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

            </div>

        </div>
    </div>

</div>
<?php /**PATH C:\xampp\htdocs\lbase\resources\views/livewire/productos-front.blade.php ENDPATH**/ ?>