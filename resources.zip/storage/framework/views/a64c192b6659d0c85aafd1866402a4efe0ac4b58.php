<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Productos de <?php echo e($categoria->categoria); ?>

        </h2>
     <?php $__env->endSlot(); ?>


    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg px-4 py-4">

                <div class="bg-white">
                    <div class="mx-auto max-w-2xl py-12 px-4 sm:py-24 sm:px-6 lg:max-w-7xl lg:px-8">

                        

                        <div class="grid grid-cols-1 sm:grid-cols-4">

                            <div class="grid col-span-3">
                                

                                <div
                                    class="grid grid-cols-1 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 xl:gap-x-8">

                                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(route('productos.show', [$categoria->slug, $producto])); ?>"
                                            class="group">
                                            <div
                                                class="aspect-w-1 aspect-h-1 w-full overflow-hidden rounded-lg bg-gray-200 xl:aspect-w-7 xl:aspect-h-8">
                                                <picture>
                                                    <source
                                                        srcset="<?php echo e(asset('storage/productos/' . $producto->id . '.webp')); ?>"
                                                        type="image/webp">
                                                    <img alt="<?php echo e($producto->nombre); ?>"
                                                        src="<?php echo e(asset('storage/productos/' . $producto->id . '.jpg')); ?>"
                                                        class="object-cover object-center group-hover:opacity-75">
                                                </picture>

                                            </div>
                                            <h3 class="mt-4 text-sm text-gray-700"><?php echo e($producto->nombre); ?></h3>
                                            <p class="mt-1 text-lg font-medium text-gray-900">$
                                                <?php echo e($producto->precioLista); ?></p>
                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <!-- More products... -->
                                </div>


                            </div>

                            <div class="grid grid-cols-1">
                                <h3 class="block px-2 py-3 bg-gray-300">Otras categorias</h3>
                                <ul role="list" class="px-2 py-3 font-medium text-gray-900">
                                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="block px-2 py-3 border-b">
                                            <a href="<?php echo e(route('productos.categoria', $categoria->slug)); ?>">
                                                <?php echo e($categoria->categoria); ?></a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>

                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\lbase\resources\views/productos/categoria.blade.php ENDPATH**/ ?>