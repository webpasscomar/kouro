<div class="relative flex h-28 text-gray-400 bg-gray-900 mt-20 items-center justify-center p-10 text-center">
    <p><strong>Kouro</strong> - © Copyright 2023 - Todos los derechos reservados.</p>
    <button class="absolute right-10 bottom-7 bg-gray-800 text-white p-3 rounded-full w-12 h-12 shadow shadow-slate-600 hover:bg-gray-700" id="btn-top"><i class="fas fa-chevron-up"></i></button>
</div><?php /**PATH C:\xampp\htdocs\lbase\resources\views/components/footer.blade.php ENDPATH**/ ?>