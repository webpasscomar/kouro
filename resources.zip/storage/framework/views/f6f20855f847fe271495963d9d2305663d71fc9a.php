<div>

    <h1>Detalle del producto</h1>

    <div class="grid grid-cols-12 gap-6 pt-8">
        <div class="col-span-9">
            <div class="grid grid-cols-12 gap-6">
                <div class="col-span-6">
                    <img class="w-full h-96 object-cover object-center"
                        src="<?php echo e(asset('storage/productos/' . $producto->imagen)); ?>" alt="<?php echo e($producto->nombre); ?>">
                </div>
                <div class="col-span-6">
                    <h2 class="text-gray-900 font-bold text-3xl mb-2" id="producto_id" wire:model="producto_id"> Id
                        <?php echo e($producto->id); ?></h2>
                    <h2 class="text-gray-900 font-bold text-3xl mb-2"> Nombre <?php echo e($producto->nombre); ?></h2>
                    <p class="text-gray-700 text-base">Desc. Corta <?php echo e($producto->descCorta); ?></p>
                    <p class="text-gray-700 text-base font-bold mt-2">Precio Lista <?php echo e($producto->precioLista); ?></p>
                    <p class="text-gray-700 text-base font-bold mt-2">Precio Oferta <?php echo e($producto->precioOferta); ?></p>
                    <p class="text-gray-700 text-base font-bold mt-2">Codigo <?php echo e($producto->codigo); ?></p>

                    <div class="mt-4">
                        <label class="block font-bold text-gray-700">Talle:</label>
                        <select class="form-select mt-1 block w-full" id="talle_id" wire:model="talle_id"
                            wire:change="checkstock()">
                            <option value="0">Seleccione un Talle</option>
                            <?php $__currentLoopData = $talles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $talle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($talle['talle_id']); ?>"><?php echo e($talle['talle']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="mt-4">
                        <label class="block font-bold text-gray-700">Color:</label>
                        <select class="form-select mt-1 block w-full" id="color_id" wire:model="color_id"
                            wire:change="checkstock()">
                            <option value="0">Seleccione un Color</option>
                            <?php $__currentLoopData = $colores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($color['color_id']); ?>"><?php echo e($color['color']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mt-4">
                        <button
                            class="py-2 px-4 bg-blue-500 hover:bg-blue-600 text-white font-bold rounded-md
                                       shadow-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                            wire:click.prevent="incrementa()">
                            +
                        </button>
                        <input class="py-2 px-2 " type="numeric" id="cantidad" wire:model="cantidad"
                            wire:change="checkstock()" />
                        <button
                            class="py-2 px-4 bg-blue-500 hover:bg-blue-600 text-white font-bold rounded-md
                                      shadow-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                            wire:click.prevent="decrementa()">
                            -
                        </button>
                        <?php if(parametro(10) === 'S'): ?>
                            Disponibles<input class="py-2 px-2 " type="numeric" id="disponibles"
                                wire:model="disponibles" disabled></input>
                        <?php endif; ?>
                    </div>

                    <div class="mt-4">
                        <?php if(parametro(10) === 'S'): ?>
                            <button
                                class="py-2 px-4
                            <?php echo e(($cantidad > $disponibles) | ($talle_id == 0) | ($color_id == 0)
                                ? 'bg-slate-100 hover:bg-slate-200 text-{212 212 216}'
                                : ' bg-blue-500 hover:bg-blue-600 text-white'); ?>

                                                           font-bold rounded-md
                            shadow-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2
                            <?php echo e(($cantidad > $disponibles) | ($talle_id == 0) | ($color_id == 0) ? 'disabled' : ''); ?>

                            "
                                wire:click.prevent="agregarcarrito()">
                                <?php echo e($cantidad > $disponibles && $talle_id > 0 && $color_id > 0 ? 'Sin stock disponible' : ' Agregar al carrito'); ?>


                            </button>
                        <?php else: ?>
                            <button
                                class="py-2 px-4  bg-blue-500 hover:bg-blue-600 text-white  font-bold rounded-md shadow-md focus:outline-none focus:ring-2
                                         focus:ring-blue-500 focus:ring-offset-2 "
                                wire:click.prevent="agregarcarrito()">Agregar al carrito</button>
                        <?php endif; ?>
                        <div>


                            

                        </div>




                    </div>
                </div>
            </div>
        </div>

        <div class="col-span-3">
            
            <div class="grid grid-cols-1">
                <h3 class="block px-2 py-3 bg-gray-300">Otras categorias</h3>
                <ul role="list" class="px-2 py-3 font-medium text-gray-900">
                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="block px-2 py-3 border-b">
                            <a href="<?php echo e(route('productos.categoria', $categoria['slug'])); ?>">
                                <?php echo e($categoria['categoria']); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>

    </div>


</div>
<?php /**PATH C:\xampp\htdocs\lbase\resources\views/livewire/producto-front.blade.php ENDPATH**/ ?>