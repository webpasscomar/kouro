<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'WebPass - Ecommerce ')); ?></title>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">


    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/fontawesome-free/css/all.min.css')); ?>">

    <?php echo \Livewire\Livewire::styles(); ?>


    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="https://cdn.jsdelivr.net/npm/tw-elements/dist/js/index.min.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body class="font-sans antialiased">
    <?php
        use Illuminate\Support\Str;
        use Livewire\Livewire;
    ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.banner','data' => []]); ?>
<?php $component->withName('jet-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <div class="min-h-screen bg-gray-100">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('navigation')->html();
} elseif ($_instance->childHasBeenRendered('M0T8fUp')) {
    $componentId = $_instance->getRenderedChildComponentId('M0T8fUp');
    $componentTag = $_instance->getRenderedChildComponentTagName('M0T8fUp');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('M0T8fUp');
} else {
    $response = \Livewire\Livewire::mount('navigation');
    $html = $response->html();
    $_instance->logRenderedChild('M0T8fUp', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        <!-- Page Heading -->
        <?php if(isset($header)): ?>
            <header class="bg-white shadow">
                <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                    <?php echo e($header); ?>

                </div>
            </header>
        <?php endif; ?>

        <!-- Page Content -->
        <main>
            <div>
                <?php if(isset($slot)): ?>
                    <?php echo e($slot); ?>

                <?php else: ?>
                    <?php echo $__env->yieldContent('content'); ?>
                    <?php endif; ?>
                </div>
            </main>

            

            


            <!-- Page Content -->
            

            

        </div>
        
        <?php echo $__env->yieldPushContent('modals'); ?>

        <?php echo \Livewire\Livewire::scripts(); ?>


        <script>
            Livewire.on('alertSave', function() {
                Swal.fire(
                    'Excelente!',
                    'Ha sido guardado correctamente!',
                    'success'
                )
            });

            Livewire.on('alertDelete', id => {
                Swal.fire({
                    title: '¿Está seguro /a?',
                    text: "La acción no podrá ser revertida!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Si, borrar!'
                }).then((result) => {


                    if (result.isConfirmed) {
                        // alert('Borrar el id: ' + id);
                        Livewire.emit('delete', id);

                        Swal.fire(
                            'Borrado!',
                            'Ha sido eliminado con éxito.',
                            'success'
                        )
                    }
                })
            })


            Livewire.on('alertCarritoDelete', (idproducto,idtalle,idcolor) =>  {
                Swal.fire({
                    title: '¿Está seguro /a?',
                    text: "La acción no podrá ser revertida!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Si, borrar!'
                }).then((result) => {


                    if (result.isConfirmed) {
                        Livewire.emit('delete', idproducto,idtalle,idcolor);

                        // Swal.fire(
                        //     'Borrado!',
                        //     'Ha sido eliminado con éxito.',
                        //     'success'
                        // )
                    }
                })
            })

            //emit del cambio de cantidades en  carrito
            Livewire.on('carrito', function(mensaje)  {
                Swal.fire(
                    'Excelente!',
                    mensaje['mensaje'] ,
                    'success'
                )
            });


             //emit mensaje negativo
             Livewire.on('mensajeNegativo', function(mensaje)  {
                Swal.fire({
                    title: 'Atencion',
                    text: mensaje['mensaje'] ,
                    icon: 'warning',
                    showCloseButton: true}
                )
            });


                 //emit mensaje positivo
                 Livewire.on('mensajePositivo', function(mensaje)  {
                Swal.fire({
                    title: 'Excelente!',
                    text: mensaje['mensaje'] ,
                    icon: 'success',
                    showCloseButton: true}
                )
            });
        </script>

    </body>

    </html>
<?php /**PATH C:\xampp\htdocs\lbase\resources\views/layouts/app.blade.php ENDPATH**/ ?>